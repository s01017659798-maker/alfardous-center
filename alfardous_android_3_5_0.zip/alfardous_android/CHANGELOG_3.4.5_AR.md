# سجل التحديث 3.4.5

- دمج واجهة HTML مراجعة 3.4.5 داخل أصول تطبيق Android.
- مزامنة `versionName` إلى 3.4.5 وزيادة `versionCode` إلى 11.
- الاحتفاظ بإعداد WebViewAssetLoader والواجهة المحلية.
- لم يتم الادعاء ببناء APK؛ يلزم Android SDK وGradle وJDK 17 على جهاز البناء.

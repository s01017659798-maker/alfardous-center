package com.alfardous.center;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.URLUtil;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private WebViewAssetLoader assetLoader;
    private AndroidFileBridge fileBridge;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 29, 53));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 29, 53));
        webView = new WebView(this);
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setBackgroundColor(android.graphics.Color.rgb(243, 245, 248));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setDefaultTextEncodingName("UTF-8");
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                    catch (Exception ignored) { return false; }
                }
                return false;
            }
        });
        fileBridge = new AndroidFileBridge(this);
        webView.addJavascriptInterface(fileBridge, "AndroidFileBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this, "تعذر فتح اختيار الملفات", Toast.LENGTH_LONG).show(); return false; }
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                String guessedName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                if (guessedName == null || guessedName.trim().isEmpty()) guessedName = "alfardous-download-" + System.currentTimeMillis();
                req.setTitle(guessedName);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, guessedName);
                ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this, "بدأ تنزيل الملف", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "تعذر تنزيل الملف على هذا الجهاز", Toast.LENGTH_LONG).show(); }
        });
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    /** Receives Blob exports from the local HTML app and saves them to Downloads. */
    public static class AndroidFileBridge {
        private final Activity activity;
        private OutputStream output;
        private Uri pendingUri;
        private File legacyFile;
        private String mimeType = "application/octet-stream";
        private String fileName = "alfardous-export.bin";
        private boolean failed;

        AndroidFileBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface public synchronized void begin(String name, String type) {
            closeQuietly(); failed = false; pendingUri = null; legacyFile = null;
            fileName = safeName(name); mimeType = (type == null || type.isEmpty()) ? "application/octet-stream" : type;
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AlfardousCenter");
                    pendingUri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (pendingUri == null) throw new IOException("تعذر إنشاء ملف التنزيل");
                    output = activity.getContentResolver().openOutputStream(pendingUri);
                } else {
                    File dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) dir = activity.getFilesDir();
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد التنزيلات");
                    legacyFile = new File(dir, fileName);
                    output = new FileOutputStream(legacyFile);
                }
                if (output == null) throw new IOException("تعذر فتح ملف التنزيل");
            } catch (Exception e) { failed = true; cleanupPending(); show("تعذر تجهيز الملف للحفظ: " + e.getMessage()); }
        }

        @JavascriptInterface public synchronized void append(String base64Chunk) {
            if (failed || output == null || base64Chunk == null) return;
            try { output.write(android.util.Base64.decode(base64Chunk, android.util.Base64.DEFAULT)); }
            catch (Exception e) { failed = true; closeQuietly(); cleanupPending(); show("حدث خطأ أثناء كتابة الملف"); }
        }

        @JavascriptInterface public synchronized void finish() {
            if (failed || output == null) { closeQuietly(); cleanupPending(); return; }
            try {
                output.flush(); output.close(); output = null;
                show(Build.VERSION.SDK_INT >= 29 ? "تم حفظ الملف في التنزيلات / AlfardousCenter" : "تم حفظ الملف داخل مجلد تنزيلات التطبيق");
            } catch (Exception e) { cleanupPending(); show("تعذر إكمال حفظ الملف"); }
        }

        private String safeName(String name) {
            String n = (name == null || name.trim().isEmpty()) ? "alfardous-export.bin" : name;
            n = n.replaceAll("[\\/:*?\"<>|]", "_");
            return n.length() > 100 ? n.substring(n.length()-100) : n;
        }
        private void show(String message) { activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_LONG).show()); }
        private void closeQuietly() { try { if (output != null) output.close(); } catch (Exception ignored) {} output = null; }
        private void cleanupPending() {
            if (pendingUri != null) { try { activity.getContentResolver().delete(pendingUri, null, null); } catch (Exception ignored) {} pendingUri = null; }
            if (legacyFile != null && legacyFile.exists()) { // Keep incomplete file out of sight by deleting it.
                //noinspection ResultOfMethodCallIgnored
                legacyFile.delete(); legacyFile = null;
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
                else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount(); results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.removeJavascriptInterface("AndroidFileBridge"); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
